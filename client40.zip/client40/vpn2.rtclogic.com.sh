sudo openvpn --config vpn2.rtclogic.com.client.ovpn
